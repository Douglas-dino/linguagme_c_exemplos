#include <stdio.h>

int main(){
    int va=0, vb=0, sab=0;
    printf("Digite o valor a: \n");
    scanf("%d",&va);
    printf("Digite o valor b: \n");
    scanf("%d",&vb);
    sab = va + vb;
    printf("Soma de VA + VB = %d \n",sab);
}