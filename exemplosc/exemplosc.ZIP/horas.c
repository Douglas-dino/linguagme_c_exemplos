#include <stdio.h>

int main(){
    printf("Caracter %c\n",'O');
    printf("Inteiro  %d\n",42);
    printf("Notacao cientifica %e\n",42.234234);
    printf("Notacao cientifica %E\n",42.234234);
    printf("Reais %.2f\n",42.234234);
    printf("Porcentagem %%\n");
    return 0;
}