#include <stdio.h>

int main(){
    printf("Hello\nWorld!\n");
    return 0;
}