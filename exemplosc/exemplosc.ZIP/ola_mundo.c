#include <stdio.h>

int main(){
    for (int i = 9;i >= 0;i-=2){
        printf("%d\n\n",i);
    }
    return 0;
}