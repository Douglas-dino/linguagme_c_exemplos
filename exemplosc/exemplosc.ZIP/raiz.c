#include <stdio.h>
#include <math.h>

int main(){
    float raiz = sqrt(4);
    printf("Raiz = %f",raiz);
}